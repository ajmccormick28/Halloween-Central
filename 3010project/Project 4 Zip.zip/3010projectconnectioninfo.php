<?php
	session_start();
	$servername = "localhost";
	$dbname = "project";
	$uname = "root";
	$psword = "";
?>